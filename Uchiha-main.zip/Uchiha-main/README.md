

# Uchiha Trio Glitch Render

A Python and OpenCV script that generates a cinematic three-character Uchiha visual effect, optimized for widescreen (16:10) screens (like MacBooks) to eliminate gray bars.

The animation sequence features:

1. **Laser Scan:** A colored scanline revealing high-contrast neon outlines.
2. **Impact Glitch:** Localized camera shake and RGB channel glitches.
3. **Cinematic Hold:** Reveal of the full images with dynamic foreground bokeh, background embers, and random purple neon lightning arcs.

## File Structure (Crucial)

To run the script, all four files shown below must be placed in the same directory:

```text
/your_folder/
├── itachi.py      <- The main Python script
├── itachi.png      <- Left column image
├── madara.png      <- Center column image
└── sasuke.png      <- Right column image

```

## Requirements

* Python 3.8+
* `opencv-python`
* `numpy`

```bash
pip install opencv-python numpy

```

## Usage

1. Open your terminal or command prompt.
2. Navigate to this folder.
3. Run the script with Python:

```bash
python itachi.py

```

Press `q` or `Esc` within the render window at any time to close it.

## Customization

Variables such as resolution (currently set to 1920x1200 for 16:10), animation timings, and particle counts can be adjusted directly at the top of the `itachi.py` script.

import os
import random
import cv2
import numpy as np

# --- CONFIGURATION ---
script_dir = os.path.dirname(os.path.abspath(__file__))

IMAGE_PATHS = [
    os.path.join(script_dir, 'itachi.png'),
    os.path.join(script_dir, 'madara.png'),
    os.path.join(script_dir, 'sasuke.png')
]

# Changed to 16:10 ratio to eliminate the gray padding on Mac screens
CANVAS_W, CANVAS_H = 1920, 1200  
FPS = 60
WINDOW_NAME = "Uchiha Trio Scan"
FULLSCREEN = True

SCAN_SECONDS = 3.5       
GLITCH_SECONDS = 0.5     
FINAL_HOLD_SECONDS = 5.0 

SCANNER_COLOR = (50, 50, 255) 
NEON_INTENSITY = 1.8

# Background Embers
NUM_EMBERS = 250  
ember_x = np.random.rand(NUM_EMBERS) * CANVAS_W
ember_y = np.random.rand(NUM_EMBERS) * CANVAS_H
ember_speed = np.random.uniform(2, 6, NUM_EMBERS)
ember_drift = np.random.uniform(-1.5, 1.5, NUM_EMBERS)
ember_size = np.random.randint(1, 4, NUM_EMBERS)

# Foreground 3D Bokeh 
NUM_BOKEH = 25
bokeh_x = np.random.rand(NUM_BOKEH) * CANVAS_W
bokeh_y = np.random.rand(NUM_BOKEH) * CANVAS_H
bokeh_speed = np.random.uniform(8, 16, NUM_BOKEH)
bokeh_size = np.random.randint(10, 30, NUM_BOKEH) 

def load_and_tile_columns(paths, total_w, total_h):
    valid_images = []
    for p in paths:
        if os.path.exists(p):
            img = cv2.imread(p)
            if img is not None:
                valid_images.append(img)
    
    if not valid_images:
        raise FileNotFoundError("Could not find the specified images. Check filenames.")

    num_images = len(valid_images)
    slot_w = total_w // num_images
    tiled_canvas = np.zeros((total_h, total_w, 3), dtype=np.uint8)
    
    for i, img in enumerate(valid_images):
        ih, iw = img.shape[:2]
        scale = max(slot_w / iw, total_h / ih)
        new_w = max(1, int(iw * scale))
        new_h = max(1, int(ih * scale))
        
        resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)
        y_start = (new_h - total_h) // 2
        x_start = (new_w - slot_w) // 2
        cropped = resized[y_start:y_start+total_h, x_start:x_start+slot_w]
        
        x_offset = i * slot_w
        tiled_canvas[0:total_h, x_offset:x_offset+slot_w] = cropped

        if i > 0:
            cv2.line(tiled_canvas, (x_offset, 0), (x_offset, total_h), (10, 10, 10), 6)

    return tiled_canvas

def make_crimson_neon_edges(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 7, 50, 50)
    edges = cv2.Canny(gray, 40, 120)
    
    kernel = np.ones((2, 2), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=1)

    color_layer = np.zeros_like(img)
    color_layer[edges > 0] = (30, 30, 255) 

    glow = cv2.GaussianBlur(color_layer, (0, 0), sigmaX=8, sigmaY=8)
    return cv2.addWeighted(color_layer, 1.2, glow, NEON_INTENSITY, 0)

def apply_rgb_glitch(frame, intensity=15):
    glitched = np.zeros_like(frame)
    h, w = frame.shape[:2]
    
    shift_b = random.randint(-intensity, intensity)
    shift_g = random.randint(-intensity, intensity)
    shift_r = random.randint(-intensity, intensity)
    
    M_b = np.float32([[1, 0, shift_b], [0, 1, 0]])
    M_g = np.float32([[1, 0, shift_g], [0, 1, 0]])
    M_r = np.float32([[1, 0, shift_r], [0, 1, 0]])
    
    glitched[:, :, 0] = cv2.warpAffine(frame[:, :, 0], M_b, (w, h))
    glitched[:, :, 1] = cv2.warpAffine(frame[:, :, 1], M_g, (w, h))
    glitched[:, :, 2] = cv2.warpAffine(frame[:, :, 2], M_r, (w, h))
    
    for _ in range(random.randint(5, 15)):
        y = random.randint(0, h - 5)
        thickness = random.randint(1, 4)
        glitched[y:y+thickness, :] = 0
        
    return glitched

def apply_camera_shake(frame, intensity=25):
    h, w = frame.shape[:2]
    dx = random.randint(-intensity, intensity)
    dy = random.randint(-intensity, intensity)
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    return cv2.warpAffine(frame, M, (w, h))

def draw_particles(frame, time_idx):
    global ember_x, ember_y, bokeh_x, bokeh_y
    
    # Update Embers
    ember_y -= ember_speed
    ember_x += np.sin((time_idx * 0.05) + ember_drift) * 1.5
    reset_mask = ember_y < -20
    ember_y[reset_mask] = CANVAS_H + 20
    ember_x[reset_mask] = np.random.rand(np.sum(reset_mask)) * CANVAS_W
    
    # Update Bokeh
    bokeh_y -= bokeh_speed
    reset_mask_b = bokeh_y < -100
    bokeh_y[reset_mask_b] = CANVAS_H + 100
    bokeh_x[reset_mask_b] = np.random.rand(np.sum(reset_mask_b)) * CANVAS_W
    
    particle_canvas = np.zeros_like(frame)
    
    # Draw Background Embers
    for i in range(NUM_EMBERS):
        ex, ey, es = int(ember_x[i]), int(ember_y[i]), ember_size[i]
        cv2.circle(particle_canvas, (ex, ey), es, (150, 220, 255), -1, cv2.LINE_AA)
        cv2.circle(particle_canvas, (ex, ey), es * 4, (20, 60, 220), -1, cv2.LINE_AA)
        
    # Draw Foreground Bokeh
    for i in range(NUM_BOKEH):
        bx, by, bs = int(bokeh_x[i]), int(bokeh_y[i]), bokeh_size[i]
        cv2.circle(particle_canvas, (bx, by), bs, (15, 30, 150), -1, cv2.LINE_AA)

    particle_canvas = cv2.GaussianBlur(particle_canvas, (0, 0), sigmaX=7, sigmaY=7)
    return cv2.addWeighted(frame, 1.0, particle_canvas, 0.9, 0)

def draw_lightning(frame):
    if random.random() > 0.90:  # 10% chance per frame to strike
        lightning_canvas = np.zeros_like(frame)
        start_x = random.randint(0, CANVAS_W)
        start_y = random.randint(0, int(CANVAS_H * 0.3))
        
        pts = [(start_x, start_y)]
        curr_x, curr_y = start_x, start_y
        
        for _ in range(random.randint(6, 12)):
            curr_x += random.randint(-100, 100)
            curr_y += random.randint(50, 150)
            pts.append((curr_x, curr_y))
            
        for i in range(len(pts)-1):
            # Inner core: Bright pinkish-white
            cv2.line(lightning_canvas, pts[i], pts[i+1], (255, 220, 240), 2, cv2.LINE_AA)
            # Outer glow: Vibrant neon purple (BGR format)
            cv2.line(lightning_canvas, pts[i], pts[i+1], (255, 50, 180), 10, cv2.LINE_AA)
            
        lightning_canvas = cv2.GaussianBlur(lightning_canvas, (0, 0), sigmaX=2, sigmaY=2)
        return cv2.addWeighted(frame, 1.0, lightning_canvas, 1.0, 0)
    return frame

def main():
    try:
        base = load_and_tile_columns(IMAGE_PATHS, CANVAS_W, CANVAS_H)
    except FileNotFoundError as e:
        print(e)
        return

    neon_sketch = make_crimson_neon_edges(base)
    delay_ms = max(1, int(1000 / FPS))

    # Added WINDOW_KEEPRATIO flag to help macOS manage the fullscreen bounds
    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
    if FULLSCREEN:
        cv2.setWindowProperty(WINDOW_NAME, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    # 1. The Laser Scan Reveal
    scan_frames = max(1, int(SCAN_SECONDS * FPS))
    for frame_idx in range(scan_frames):
        canvas = np.zeros_like(base)
        progress = frame_idx / scan_frames
        current_y = int(progress * CANVAS_H)
        
        if current_y > 0:
            canvas[0:current_y, :] = neon_sketch[0:current_y, :]
            
        cv2.line(canvas, (0, current_y), (CANVAS_W, current_y), SCANNER_COLOR, 3)
        
        laser_glow = np.zeros_like(canvas)
        cv2.line(laser_glow, (0, current_y), (CANVAS_W, current_y), SCANNER_COLOR, 15)
        laser_glow = cv2.GaussianBlur(laser_glow, (0, 0), sigmaX=5, sigmaY=10)
        canvas = cv2.addWeighted(canvas, 1.0, laser_glow, 1.0, 0)

        cv2.imshow(WINDOW_NAME, canvas)
        if cv2.waitKey(delay_ms) & 0xFF in [ord('q'), 27]: return

    # 2. The RGB Glitch Impact
    glitch_frames = max(1, int(GLITCH_SECONDS * FPS))
    for _ in range(glitch_frames):
        source_frame = base if random.random() > 0.5 else neon_sketch
        
        glitched_canvas = apply_rgb_glitch(source_frame, intensity=40)
        shaking_canvas = apply_camera_shake(glitched_canvas, intensity=25)
        
        cv2.imshow(WINDOW_NAME, shaking_canvas)
        if cv2.waitKey(delay_ms) & 0xFF in [ord('q'), 27]: return

    # 3. Final Image Hold (Particles + Lightning)
    final_hold_frames = max(1, int(FINAL_HOLD_SECONDS * FPS))
    for time_idx in range(final_hold_frames):
        dynamic_frame = draw_particles(base, time_idx)
        dynamic_frame = draw_lightning(dynamic_frame)
        
        cv2.imshow(WINDOW_NAME, dynamic_frame)
        if cv2.waitKey(delay_ms) & 0xFF in [ord('q'), 27]: return

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()